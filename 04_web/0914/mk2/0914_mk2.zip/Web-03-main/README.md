# Web-03
HTML, CSS Practice repository with pair programming

오늘은 리뷰작성하기를 만들고 쇼생크 탈출 카드를 누르면 해당 페이지로 이동하는 기능을 만들었는데
디스코드 해상도가 4k를 사용해서 그런지 공유화면의 텍스트가 많이 깨져서 아쉬웠습니다.
완성이 된 후에는 github organization을 통해서 그룹을 만들고 새로운 저장소를 만들어서 웹을 배포했습니다.